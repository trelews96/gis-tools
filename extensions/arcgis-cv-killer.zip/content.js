(function () {
    'use strict';

    const TAG = '🛡️[CV-Killer]';
    const DEBUG = true;
    const log = (...a) => DEBUG && console.log(TAG, ...a);
    const warn = (...a) => DEBUG && console.warn(TAG, ...a);

    log(`Active @ ${new Date().toISOString()} on ${location.href}`);

    // ---------- URL matchers ----------
    const isQueryContingentValues = (u) => /\/FeatureServer\/queryContingentValues/i.test(u);
    const isLayerMetadata = (u) => /\/FeatureServer\/\d+(\/|\?|$)/i.test(u);
    const isWebmapItemData = (u) => /\/sharing\/rest\/content\/items\/[^/]+\/data/i.test(u);
    const shouldScrubResponse = (u) => isLayerMetadata(u) || isWebmapItemData(u);

    // ---------- Synthetic empty payload for queryContingentValues ----------
    const EMPTY_CV_PAYLOAD = () => JSON.stringify({
        layers: [],
        fieldGroups: [],
        contingentValues: []
    });

    // ---------- Recursive scrubber ----------
    function scrubContingent(obj, depth = 0) {
        if (!obj || typeof obj !== 'object' || depth > 8) return false;
        let modified = false;

        if (Array.isArray(obj)) {
            for (const item of obj) {
                if (scrubContingent(item, depth + 1)) modified = true;
            }
            return modified;
        }

        if (Array.isArray(obj.contingentValues) && obj.contingentValues.length > 0) {
            obj.contingentValues = [];
            modified = true;
        }
        if (Array.isArray(obj.fieldGroups) && obj.fieldGroups.length > 0) {
            obj.fieldGroups = [];
            modified = true;
        }
        if (obj.contingentValuesDefinition && typeof obj.contingentValuesDefinition === 'object') {
            obj.contingentValuesDefinition = { fieldGroups: [], contingentValues: [] };
            modified = true;
        }

        for (const key of ['layerDefinition', 'layers', 'tables', 'featureCollection', 'operationalLayers']) {
            const v = obj[key];
            if (v && typeof v === 'object') {
                if (scrubContingent(v, depth + 1)) modified = true;
            }
        }

        return modified;
    }

    function extractUrl(input) {
        if (!input) return '';
        if (typeof input === 'string') return input;
        if (typeof URL !== 'undefined' && input instanceof URL) return input.href;
        if (typeof Request !== 'undefined' && input instanceof Request) return input.url;
        if (typeof input.url === 'string') return input.url;
        return '';
    }

    // ============ FETCH ============
    const originalFetch = window.fetch;
    window.fetch = async function (...args) {
        const url = extractUrl(args[0]);

        if (isQueryContingentValues(url)) {
            log('FETCH short-circuit →', url.split('?')[0]);
            return new Response(EMPTY_CV_PAYLOAD(), {
                status: 200,
                statusText: 'OK',
                headers: new Headers({ 'Content-Type': 'application/json;charset=utf-8' })
            });
        }

        const response = await originalFetch.apply(this, args);

        if (!shouldScrubResponse(url) || !response.ok) return response;
        const ct = response.headers.get('content-type') || '';
        if (!ct.includes('json')) return response;

        try {
            const data = await response.clone().json();
            if (scrubContingent(data)) {
                log('FETCH scrubbed →', url.split('?')[0]);
                const headers = new Headers();
                response.headers.forEach((v, k) => headers.set(k, v));
                return new Response(JSON.stringify(data), {
                    status: response.status,
                    statusText: response.statusText,
                    headers
                });
            }
        } catch (e) {
            warn(`FETCH parse error on ${url.split('?')[0]}:`, e.message);
        }

        return response;
    };

    // ============ XHR ============
    const XHR = window.XMLHttpRequest;
    const origOpen = XHR.prototype.open;
    const origSend = XHR.prototype.send;
    const origRespTextGet = Object.getOwnPropertyDescriptor(XHR.prototype, 'responseText').get;
    const origRespGet = Object.getOwnPropertyDescriptor(XHR.prototype, 'response').get;

    XHR.prototype.open = function (method, url, ...rest) {
        this.__cvkUrl = typeof url === 'string' ? url : (url && url.href) || '';
        return origOpen.call(this, method, url, ...rest);
    };

    XHR.prototype.send = function (body) {
        const xhr = this;
        const url = xhr.__cvkUrl || '';

        const isCV = isQueryContingentValues(url);
        const wantScrub = shouldScrubResponse(url);

        if (!isCV && !wantScrub) return origSend.call(this, body);

        const cache = { raw: null, text: null, data: null };

        const computeScrubbedText = () => {
            if (xhr.readyState !== 4) return origRespTextGet.call(xhr);

            if (isCV) {
                if (cache.text === null) {
                    cache.text = EMPTY_CV_PAYLOAD();
                    cache.data = JSON.parse(cache.text);
                    log('XHR replaced queryContingentValues →', url.split('?')[0]);
                }
                return cache.text;
            }

            const raw = origRespTextGet.call(xhr);
            if (cache.raw === raw && cache.text !== null) return cache.text;

            try {
                const data = JSON.parse(raw);
                if (scrubContingent(data)) {
                    cache.raw = raw;
                    cache.text = JSON.stringify(data);
                    cache.data = data;
                    log('XHR scrubbed →', url.split('?')[0]);
                    return cache.text;
                }
            } catch (e) {
                warn(`XHR parse error on ${url.split('?')[0]}:`, e.message);
            }
            return raw;
        };

        Object.defineProperty(xhr, 'responseText', {
            configurable: true,
            get: computeScrubbedText
        });

        Object.defineProperty(xhr, 'response', {
            configurable: true,
            get() {
                const t = xhr.responseType;
                if (t === '' || t === 'text') return computeScrubbedText();
                if (t === 'json') {
                    computeScrubbedText();
                    return cache.data !== null ? cache.data : origRespGet.call(xhr);
                }
                return origRespGet.call(xhr);
            }
        });

        return origSend.call(this, body);
    };

})();